# to understand the code for prediction of resume 
# it is for understand 

import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns

df=pd.read_csv(r"C:\Users\Tushar\Downloads\archive\UpdatedResumeDataSet.csv")
print(df.head()) # to view our data consist of 
print(df.shape) # to view how much data like 92 rows 10 columns 
print(df['Category'].value_counts())  # to print the categody reled  conts 

plt.figure(figsize=(15,10)) # to adjust grpah size 
sns.countplot(df['Category']) # taking categorical data 
plt.xticks(rotation=90)  # to rotate the name of categotrical 90 degree
# plt.show()  # plotting a graph 


# now we cretee pie graph of thes ecatogical values 


# storing count data of categocial data
counts=df['Category'].value_counts()

print(df['Category'].unique())
labels=df['Category'].unique()  # labels are the names of categories 

# creating pie graph
plt.pie(counts,labels=labels,autopct='%1.1f%%',shadow=True,colors=plt.cm.coolwarm(np.linspace(0,1,3)))
# plt.show()



# exploring resume
print(df['Category'][0])
print(df['Resume'][0])



# cleaning resume 
import re  # re library is used for working with regular expressions to search, replace, or modify strings

def CleanResume(txt):
    # Removing URLs from the text (any string starting with 'http' and followed by any characters)
    cleantxt = re.sub('http\S+\s', ' ', txt)  # Replace URLs with a space
    
    # Removing mentions (words starting with '@', usually for usernames in social media)
    cleantxt = re.sub('@\S+', ' ', cleantxt)  # Replace mentions with a space
    
    # Removing hashtags (words starting with '#')
    cleantxt = re.sub('#\S+', ' ', cleantxt)  # Replace hashtags with a space
    
    # Removing the terms 'RT' (Retweet) and 'CC' (Carbon Copy) which are common in social media text
    cleantxt = re.sub('RT|CC', ' ', cleantxt)  # Replace 'RT' or 'CC' with a space
    
    # Removing all special characters like punctuation (e.g., !, @, #, $, etc.)
    cleantxt = re.sub('[%s]' % re.escape("""!"#$%&'()*+,-./:;<=>?@[\]^_'{|}~"""), ' ', cleantxt)
    
    # Removing non-ASCII characters (characters not in the range of standard English letters and symbols)
    cleantxt = re.sub(r'[^\x00-\x7f]', ' ', cleantxt)  # Replace non-ASCII characters with a space
    
    # Removing extra spaces (sequences of multiple spaces) and replacing them with a single space
    cleantxt = re.sub('\s+', ' ', cleantxt)  # Normalize spaces by replacing multiple spaces with a single space
    
    return cleantxt

# Example usage of the CleanResume function
f = CleanResume("my name is! tushar? and profile link is https://w3schools  this is the email @gmailor may be #### ")
print(f)



# now we overall clean all resums using this function with lambda and storig in source 
df['Resume']=df['Resume'].apply(lambda x: CleanResume(x))
print(df['Resume'][0])





# now we convert word in to categorical values  like cateorical values in to numbers 
from sklearn.preprocessing import LabelEncoder
le=LabelEncoder()
le.fit(df['Category'])
df['Category']=le.transform(df['Category'])

print(df['Category'].unique())   # it give res like numbrs 2,12 




# // now we do vactoriztaion likw we convert all the resumes in to the vectors matices
from sklearn.feature_extraction.text import TfidfVectorizer
tfidf=TfidfVectorizer(stop_words='english')

tfidf.fit(df['Resume'])
requiered_text=tfidf.transform(df['Resume'])   # it convert resume string in to matrices like one  word is 1 in every row 

print(df)


# now we do splitting 
# used to split a dataset into two (or more) subsets: typically a training set and a testing set. 
from sklearn.model_selection import train_test_split

#  in this x_tariny y train have 80% data to train and a_test and y_test hase 20 percent data to test 
x_train,x_test,y_train,y_test=train_test_split(requiered_text,df['Category'],test_size=0.2,random_state=42)

# 80%
print(x_train.shape )
# 20%
print(x_test.shape )



# now we use k neighbour classifier to train 
from sklearn.neighbors import KNeighborsClassifier
from sklearn.multiclass import OneVsRestClassifier
from sklearn.metrics import accuracy_score

clf=OneVsRestClassifier(KNeighborsClassifier())
# trsining set
clf.fit(x_train,y_train)


# for pdecton test cases 
y_pred=clf.predict(x_test)
# our prdeiction 
print(y_pred)


# now we check accurcy by provide ytrain data and y predict data 
print(accuracy_score(y_test,y_pred))  # y_test is real data and y_pred is predictioon of xtest resulut in y_test data 

# # making recommendation sysytem 
# The code you've provided uses the pickle module in Python, which is used to serialize and save Python objects to files so that they can be later loaded (deserialized) and reused without having to recompute or recreate the objects from scratch.

# we rae making obj and saving in pkl file beacsue re calculating the model is time consuming 
import pickle
pickle.dump(tfidf,open('tfidf.pkl','wb'))
pickle.dump(clf,open('clf.pkl','wb'))


# sample resume
my_resume =   """Samuel Thompson
789 Technology Drive, Suite 101
Innovate City, State, ZIP
Email: samuel.thompson@techmail.com
Phone: (654) 987-6543
LinkedIn: linkedin.com/in/samthompsonetl
Portfolio: samuelthompsonetl.com

Objective
Highly analytical ETL Developer with over four years of professional experience in designing and implementing robust Extract, Transform, and Load processes for large-scale data systems. I seek to contribute my skills in data integration and pipeline automation to a forward-thinking organization that values data-driven insights.

Core Competencies
- In-depth expertise in building and optimizing ETL pipelines using tools such as Apache Nifi, Talend, and Informatica PowerCenter
- Proficient in relational database systems like MySQL, PostgreSQL, and Oracle, along with NoSQL databases including MongoDB and Cassandra
- Extensive experience with scripting languages like Python and Shell for automating data workflows
- Adept in data warehousing concepts, including star schemas, snowflake schemas, and OLAP/OLTP architecture
- Strong grasp of SQL query optimization, data modeling, and schema design
- Experience with cloud-based data services such as AWS Redshift, Google BigQuery, and Azure Data Lake for seamless data integration
- Excellent communication skills, working closely with cross-functional teams to ensure data reliability, accuracy, and security

Professional Experience

Senior ETL Developer
Data Solutions Inc., Innovate City, State
July 2020 – Present
- Architected and implemented end-to-end ETL workflows for a global e-commerce company, enabling real-time data integration and reporting,
"""



import pickle 

# load the trainsed clasifer 
clf=pickle.load(open('clf.pkl','rb'))    # clf is trained dataset 


# clenan rwsume 
cleaned_resume=CleanResume(my_resume)


# transforming the clean reume  uding tfid vactorise r
input_feature=tfidf.transform([cleaned_resume])

# making the prediuction using loaded classifier 
prdiction_id=clf.predict(input_feature)[0]
print(prdiction_id)


# dict of field reltae to numbers 
category_mapping = {
    6: 'Data Science',
    12: 'HR',
    0: 'Advocate',
    1: 'Arts',
    24: 'Web Designing',
    16: 'Mechanical Engineer',
    22: 'Sales',
    14: 'Health and fitness',
    5: 'Civil Engineer',
    15: 'Java Developer',
    4: 'Business Analyst',
    21: 'SAP Developer',
    2: 'Automation Testing',
    11: 'Electrical Engineering',
    18: 'Operations Manager',
    20: 'Python Developer',
    8: 'DevOps Engineer',
    17: 'Network Security Engineer',
    19: 'PMO',
    7: 'Database',
    13: 'Hadoop',
    10: 'ETL Developer',
    9: 'DotNet Developer',
    3: 'Blockchain',
    23: 'Testing'
}


# it will provide corresponding valure for dict related to  prediction id as key  and handle empty valje cases  means unkonwn wil print 
category_name=category_mapping.get(prdiction_id,"unknown")

print("predicted_category is" ,category_name )

