#  important/main code only for prediction resume not  undertanding 


import pandas as pd
import numpy as np
import re
from sklearn.preprocessing import LabelEncoder
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.model_selection import train_test_split
from sklearn.neighbors import KNeighborsClassifier
from sklearn.multiclass import OneVsRestClassifier
from sklearn.metrics import accuracy_score
import pickle

# Load dataset
df = pd.read_csv(r"C:\Users\Tushar\Downloads\archive\UpdatedResumeDataSet.csv")

# Clean resume function
def CleanResume(txt):
    cleantxt = re.sub('http\S+\s', ' ', txt)
    cleantxt = re.sub('@\S+', ' ', cleantxt)
    cleantxt = re.sub('#\S+', ' ', cleantxt)
    cleantxt = re.sub('RT|CC', ' ', cleantxt)
    cleantxt = re.sub('[%s]' % re.escape("""!"#$%&'()*+,-./:;<=>?@[\]^_'{|}~"""), ' ', cleantxt)
    cleantxt = re.sub(r'[^\x00-\x7f]', ' ', cleantxt)
    cleantxt = re.sub('\s+', ' ', cleantxt)
    return cleantxt

# Clean all resumes
df['Resume'] = df['Resume'].apply(lambda x: CleanResume(x))

# Convert categories to numerical values
le = LabelEncoder()
le.fit(df['Category'])
df['Category'] = le.transform(df['Category'])

# Vectorization
tfidf = TfidfVectorizer(stop_words='english')
tfidf.fit(df['Resume'])
required_text = tfidf.transform(df['Resume'])

# Split dataset
x_train, x_test, y_train, y_test = train_test_split(required_text, df['Category'], test_size=0.2, random_state=42)

# Train classifier
clf = OneVsRestClassifier(KNeighborsClassifier())
clf.fit(x_train, y_train)

# Make predictions
y_pred = clf.predict(x_test)

# Check accuracy
accuracy = accuracy_score(y_test, y_pred)

# Load trained classifier
clf = pickle.load(open('clf.pkl', 'rb'))

# Clean sample resume
my_resume = """Samuel Thompson
789 Technology Drive, Suite 101
Innovate City, State, ZIP
Email: samuel.thompson@techmail.com
Phone: (654) 987-6543
LinkedIn: linkedin.com/in/samthompsonetl
Portfolio: samuelthompsonetl.com

Objective
Highly analytical ETL Developer with over four years of professional experience in designing and implementing robust Extract, Transform, and Load processes for large-scale data systems. I seek to contribute my skills in data integration and pipeline automation to a forward-thinking organization that values data-driven insights.
"""

cleaned_resume = CleanResume(my_resume)

# Transform the cleaned resume
input_feature = tfidf.transform([cleaned_resume])

# Make prediction
prediction_id = clf.predict(input_feature)[0]

# Category mapping
category_mapping = {
    6: 'Data Science',
    12: 'HR',
    0: 'Advocate',
    1: 'Arts',
    24: 'Web Designing',
    16: 'Mechanical Engineer',
    22: 'Sales',
    14: 'Health and fitness',
    5: 'Civil Engineer',
    15: 'Java Developer',
    4: 'Business Analyst',
    21: 'SAP Developer',
    2: 'Automation Testing',
    11: 'Electrical Engineering',
    18: 'Operations Manager',
    20: 'Python Developer',
    8: 'DevOps Engineer',
    17: 'Network Security Engineer',
    19: 'PMO',
    7: 'Database',
    13: 'Hadoop',
    10: 'ETL Developer',
    9: 'DotNet Developer',
    3: 'Blockchain',
    23: 'Testing'
}

# Get predicted category
category_name = category_mapping.get(prediction_id, "unknown")

# Print prediction result
# print("Predicted category is", category_name)
